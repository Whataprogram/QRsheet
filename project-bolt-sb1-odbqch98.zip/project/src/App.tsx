import React, { useState } from 'react';
import { Timer, Plus, Minus, RefreshCw, Save, Settings, Moon, HelpCircle } from 'lucide-react';
import config from './config.json';

interface FormState {
  [key: string]: any;
}

function Toggle({ label, value, onChange }: { label: string; value: boolean; onChange: (value: boolean) => void }) {
  return (
    <div className="flex items-center justify-between bg-gray-800 p-4 rounded-lg mb-3">
      <span className="text-gray-300">{label}</span>
      <button 
        onClick={() => onChange(!value)}
        className={`w-12 h-6 rounded-full p-1 transition-colors ${value ? 'bg-red-600' : 'bg-gray-600'}`}
      >
        <div className={`w-4 h-4 bg-white rounded-full transition-transform ${value ? 'translate-x-6' : ''}`} />
      </button>
    </div>
  );
}

function Counter({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-3">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="text-gray-300">{label}</span>
          <HelpCircle size={16} className="text-gray-500" />
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => onChange(Math.max(0, value - 1))}
            className="bg-red-800 hover:bg-red-700 text-white p-2 rounded"
          >
            <Minus size={16} />
          </button>
          <span className="text-white text-xl w-8 text-center">{value}</span>
          <button 
            onClick={() => onChange(value + 1)}
            className="bg-red-800 hover:bg-red-700 text-white p-2 rounded"
          >
            <Plus size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}

function Slider({ label, value, onChange, min, max }: { label: string; value: number; onChange: (value: number) => void; min: number; max: number }) {
  return (
    <div className="mb-4">
      <label className="text-gray-300 block mb-2">{label}</label>
      <input 
        type="range" 
        min={min} 
        max={max} 
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full"
      />
      <div className="text-white text-center">{value}</div>
    </div>
  );
}

function Select({ label, value, options, onChange }: { label: string; value: string; options: string[]; onChange: (value: string) => void }) {
  return (
    <div className="mb-3">
      <label className="text-gray-300 block mb-2">{label}</label>
      <select 
        value={value} 
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-gray-700 text-white p-2 rounded"
      >
        {options.map(option => (
          <option key={option} value={option}>{option}</option>
        ))}
      </select>
    </div>
  );
}

function App() {
  const [formState, setFormState] = useState<FormState>(() => {
    const initialState: FormState = {};
    Object.values(config.sections).forEach(section => {
      section.fields.forEach((field: any) => {
        initialState[field.id] = field.defaultValue || 
          (field.type === 'toggle' ? false : 
           field.type === 'counter' ? 0 : 
           field.type === 'select' ? field.options[0] : 
           '');
      });
    });
    return initialState;
  });

  const updateField = (fieldId: string, value: any) => {
    setFormState(prev => ({
      ...prev,
      [fieldId]: value
    }));
  };

  const renderField = (field: any) => {
    switch (field.type) {
      case 'toggle':
        return (
          <Toggle
            key={field.id}
            label={field.label}
            value={formState[field.id]}
            onChange={(value) => updateField(field.id, value)}
          />
        );
      case 'counter':
        return (
          <Counter
            key={field.id}
            label={field.label}
            value={formState[field.id]}
            onChange={(value) => updateField(field.id, value)}
          />
        );
      case 'slider':
        return (
          <Slider
            key={field.id}
            label={field.label}
            value={formState[field.id]}
            onChange={(value) => updateField(field.id, value)}
            min={field.min}
            max={field.max}
          />
        );
      case 'select':
        return (
          <Select
            key={field.id}
            label={field.label}
            value={formState[field.id]}
            options={field.options}
            onChange={(value) => updateField(field.id, value)}
          />
        );
      case 'text':
      case 'number':
        return (
          <div key={field.id} className="mb-3">
            <label className="text-gray-300 block mb-2">{field.label}</label>
            <input
              type={field.type}
              value={formState[field.id]}
              onChange={(e) => {
                const value = e.target.value;
                if (field.type === 'number') {
                  // For match number and team number, ensure value is not negative
                  if ((field.id === 'matchNumber' || field.id === 'teamNumber') && Number(value) < 0) {
                    return;
                  }
                }
                updateField(field.id, value);
              }}
              min={field.type === 'number' ? 0 : undefined}
              className="w-full bg-gray-700 text-white p-2 rounded"
            />
          </div>
        );
      case 'textarea':
        return (
          <div key={field.id} className="mb-3">
            <label className="text-gray-300 block mb-2">{field.label}</label>
            <textarea
              value={formState[field.id]}
              onChange={(e) => updateField(field.id, e.target.value)}
              className="w-full bg-gray-700 text-white p-2 rounded h-24"
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 p-4 pb-20">
      <div className="max-w-6xl mx-auto">
        <div className="text-red-500 text-2xl font-bold mb-6 text-center">{config.title}</div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-800 p-4 rounded-lg">
            <h2 className="text-red-500 text-xl font-bold mb-4">PREMATCH</h2>
            <div className="space-y-4">
              {config.sections.prematch.fields.map((field: any) => renderField(field))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-gray-800 p-4 rounded-lg mb-4">
              <div className="flex justify-between items-center mb-4">
                <Timer className="text-gray-300" />
                <div className="text-white text-2xl">{formState.timer || "9:10"}</div>
              </div>
            </div>

            {config.sections.scoring.fields.map((field: any) => renderField(field))}
          </div>

          <div className="space-y-4">
            <div className="bg-gray-800 p-4 rounded-lg">
              <h2 className="text-gray-300 mb-4">{config.sections.postmatch.title}</h2>
              {config.sections.postmatch.fields.map((field: any) => renderField(field))}
            </div>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 bg-gray-800 p-4">
          <div className="max-w-6xl mx-auto flex justify-between">
            <button 
              onClick={() => setFormState({})}
              className="bg-red-800 hover:bg-red-700 text-white px-6 py-2 rounded flex items-center gap-2"
            >
              <RefreshCw size={16} />
              Reset Form
            </button>
            <div className="flex gap-2">
              <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded">
                <Moon size={16} />
              </button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded">
                <Settings size={16} />
              </button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded">
                <Save size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;